# Phase 76 — Smart Results & Collection Lifecycle

Implemented as one consolidated phase.

- stable in-place refresh for `results://` panels;
- built-in refresh semantics for Search, Recent Files, and Duplicate Results;
- plugin collection runtime refresh callbacks;
- host-owned refresh lifecycle cleanup;
- compact results-only pane toolbar with Refresh / Pin / Rename;
- cursor and selection preservation by resource identity after refresh;
- pinned result snapshots remain compatible with Phase 75;
- active-pane outer blue border remains removed.

Validation:

```powershell
cd frontend
node .\scripts\verify-phase73.mjs
node .\scripts\verify-phase74.mjs
node .\scripts\verify-phase75.mjs
node .\scripts\verify-phase76.mjs
npm run build
```

Then run `go build .` and `wails dev`.
