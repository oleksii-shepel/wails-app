# Phase 74 — Input & Shortcut Excellence

Phase 74 closes the remaining Input System Phase C work.

## Live rebinding
The Reassembly shortcut command now opens a real live editor rather than toggling unused state.

The editor supports:
- all currently registered runtime bindings, including Reassembly and plugins;
- keyboard single-stroke and two-step chord recording;
- mouse click, double-click, and wheel gesture recording;
- enable/disable;
- per-binding reset;
- reset all;
- search and device filtering;
- conflicts-only view;
- import/export of full override data.

Changes apply immediately without restart.

## Persistence
User customizations are stored by stable binding ID.

The `InputCustomizationService` watches the runtime binding catalog and reapplies saved overrides when bindings appear later. This is important for plugins: a plugin can load after startup and still receive the user's saved override.

User overrides are registered back into the engine as `source: user`, preserving the resolver's intended precedence:

`user > workspace > plugin > default`

## Conflict inspection
The engine now exposes binding conflicts. Conflict reporting includes:
- same-context collisions;
- global/context overlaps;
- winner and loser after source/priority resolution;
- formatted trigger.

## Plugin bindings
Backend plugin hotkeys already used `registerPluginInput`; that path is retained.

Directory `frontend.json` schema can now additionally declare `bindings`, including keyboard chords and mouse gestures. The directory loader registers commands + bindings as one owned plugin input contribution.

Example:

```json
{
  "schemaVersion": 1,
  "commands": [
    {
      "id": "refresh",
      "targetCommandId": "reassembly.manager.refresh"
    }
  ],
  "bindings": [
    {
      "id": "refresh-key",
      "commandId": "refresh",
      "trigger": {
        "device": "keyboard",
        "chord": {
          "steps": [
            { "key": "r", "modifiers": ["ctrl", "alt"] }
          ]
        }
      },
      "when": "!typing"
    }
  ]
}
```

A plugin that contributes bindings/contexts still requires the `keybindings` permission. Command-only input bundles require only `commands`.

## Mouse gestures
The engine now produces actual `drag` gestures once a held mouse button travels past an 8px threshold. Direction and drag coordinates are included in the command invocation context.

Reassembly defaults added:
- file-row left double-click → Open;
- viewer Ctrl+Wheel Up → Zoom In;
- viewer Ctrl+Wheel Down → Zoom Out.

Right-click/context-menu and native file drag/drop remain specialized UI flows and are not hijacked.

## Phase 73 compatibility
The consolidated Phase 73.11 state is the base:
- no compare dots/row decoration;
- real comparison statuses;
- public linked navigation seam;
- cursor recovery FileInfo typing fix;
- universal modal Escape handling.
