# Phase 75 — Search & Discovery Excellence

Phase 75 turns the Phase 65 results-panel primitives into one coherent discovery experience.

## One discovery surface

Global Search now has three modes:

- **Search** — query the active pane's location/provider.
- **Recent** — filter recently opened files.
- **Collections** — reopen result panels, duplicate results, and plugin-created collections.

The same modal, keyboard navigation, result opening, theming, and pane semantics apply to all three.

## Provider-aware search

`DiscoverySearchService` preserves the fast backend `Search` path for ordinary local filesystem roots.

For remote/plugin/virtual providers, it traverses through `PanelSourceRegistryService` instead. This means search uses the same provider abstraction as the pane:

- Google Drive / OneDrive / S3 provider paths;
- plugin-contributed `PanelSource`s;
- other non-local schemes that support directory listing.

Traversal is bounded by max results, max visited directories, max depth, and supports `AbortSignal`.

Wildcard `*` and `?` matching is supported in the provider traversal path.

## Saved searches and rich history

History stores the full search specification:

- root/provider path;
- query;
- recursive flag;
- type filter;
- sort mode;
- result count and timestamp.

Saved searches persist the same specification and can be recalled from any workspace. A saved search does not persist stale results; it reruns against the current provider contents.

## Recent files

Recent Files is now searchable by name or path while preserving the existing persistent MRU behavior.

## Result collections

Collections mode surfaces existing `ResultsPanelService` definitions, including plugin-created collections.

Ordinary result panels may be **pinned**. Pinned non-plugin panels persist across app sessions. Plugin-owned collection snapshots are intentionally not resurrected without their plugin; plugin lifecycle remains authoritative.

## Pane integration

Selecting a collection navigates the active directory pane to its existing `results://` path through the public pane navigation seam. Expired collections fail visibly rather than leaving a blank misleading pane.

## Validation

```powershell
cd frontend
node .\scripts\verify-phase73.mjs
node .\scripts\verify-phase74.mjs
node .\scripts\verify-phase75.mjs
npm run build
```

Then:

```powershell
cd ..
go build .
wails dev
```
