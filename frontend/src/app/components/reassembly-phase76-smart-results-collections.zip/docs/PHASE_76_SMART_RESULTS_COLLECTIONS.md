# Phase 76 — Smart Results & Collection Lifecycle

Phase 75 made searches, recent files, and result collections discoverable. Phase 76 makes those collections live.

## Refresh in place

A results panel keeps its stable `results://` identity while its entries are replaced. This means tabs, history, pinned references, and workspace state do not need a new path after every refresh.

`ResultsPanelService` now supports runtime refreshers and atomic in-place snapshot updates.

## Built-in smart collections

`SmartResultsService` automatically supplies refresh behavior for:

- global-search result panels;
- recursive search result panels;
- Recent Files;
- duplicate-finder results.

Search reruns against the original provider/root/query. Recent Files rereads the MRU. Duplicate collections rescan their original root.

## Plugin collections

`PluginResultsCollection` accepts an optional runtime `refresh()` callback.

Refresh code is never serialized. Plugin-owned persisted snapshots remain lifecycle-safe: when the plugin disappears, executable refresh behavior disappears too.

## Pane UX

When a pane is on a `results://` location, a compact collection bar appears with:

- collection title;
- kind/origin;
- item count;
- Refresh;
- Pin / Unpin;
- Rename.

Ordinary filesystem panes do not get another toolbar.

Refreshing preserves selected paths and cursor identity when those resources still exist. Stale selection is pruned and the cursor falls back to a visible entry.

## Visual correction retained

The active-pane outer blue border is removed. Active/selected state is expressed by row/tab/content state instead of boxing the whole pane.

## Validation

```powershell
cd frontend
node .\scripts\verify-phase73.mjs
node .\scripts\verify-phase74.mjs
node .\scripts\verify-phase75.mjs
node .\scripts\verify-phase76.mjs
npm run build
```

Then:

```powershell
cd ..
go build .
wails dev
```
