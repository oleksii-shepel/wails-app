import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';

const root = path.resolve(process.cwd());
const files = [
  'src/app/app.component.ts',
  'src/app/components/reassembly-directory-pane.component.ts',
  'src/app/components/reassembly-dual-pane.component.ts',
  'src/app/services/reassembly-pane-intelligence.service.ts',
];

let failed = false;

for (const rel of files) {
  const full = path.join(root, rel);
  if (!fs.existsSync(full)) {
    console.error(`missing: ${rel}`);
    failed = true;
    continue;
  }

  const source = fs.readFileSync(full, 'utf8');
  const result = ts.transpileModule(source, {
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.ESNext,
      experimentalDecorators: true,
    },
    fileName: rel,
    reportDiagnostics: true,
  });

  const diagnostics = result.diagnostics ?? [];
  if (diagnostics.length) {
    failed = true;
    console.error(`\n${rel}`);
    for (const diagnostic of diagnostics) {
      console.error(
        ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'),
      );
    }
  }
}

const manager = fs.readFileSync(
  path.join(root, 'src/app/components/reassembly-dual-pane.component.ts'),
  'utf8',
);
const pane = fs.readFileSync(
  path.join(root, 'src/app/components/reassembly-directory-pane.component.ts'),
  'utf8',
);
const app = fs.readFileSync(
  path.join(root, 'src/app/app.component.ts'),
  'utf8',
);

const forbidden = [
  ["old compare status", manager.includes("item.status !== 'equal'")],
  ["old different status", manager.includes("case 'different':")],
  ["old type mismatch status", manager.includes("case 'type-mismatch':")],
  ["private linked load", manager.includes('targetPane.load(peer')],
  ["pane compare badge", pane.includes('compare-badge')],
  ["pane compare overlay", pane.includes('compareOverlay')],
  ["HostListener KeyboardEvent", app.includes('onGlobalEscape(event: KeyboardEvent)')],
  ["cursor recovery string union", pane.includes("this.cursorPath &&\n      visible.find")],
];

for (const [label, present] of forbidden) {
  if (present) {
    console.error(`forbidden regression: ${label}`);
    failed = true;
  }
}

const phase73Bindings = [
  'reassembly.panes.link.ctrlAltL',
  'reassembly.panes.mirror.ctrlAltM',
  'reassembly.panes.follow.ctrlAltF',
  'reassembly.panes.scroll.ctrlAltS',
  'reassembly.panes.previousDifference.ctrlAltBracketLeft',
  'reassembly.panes.nextDifference.ctrlAltBracketRight',
];

for (const id of phase73Bindings) {
  const count = manager.split(id).length - 1;
  if (count !== 1) {
    console.error(`binding ${id}: expected 1 occurrence, got ${count}`);
    failed = true;
  }
}

if (failed) process.exit(1);
console.log('Phase 73 static integration checks passed.');
