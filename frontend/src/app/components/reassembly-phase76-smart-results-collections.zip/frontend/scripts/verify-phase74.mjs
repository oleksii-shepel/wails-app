import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';

const cwd = path.resolve(process.cwd());
const files = [
  'src/app/services/input-system.types.ts',
  'src/app/services/input-engine.service.ts',
  'src/app/services/keybinding-storage.service.ts',
  'src/app/services/input-customization.service.ts',
  'src/app/services/directory-plugin-package-loader.service.ts',
  'src/app/plugin/declarative-plugin-module.ts',
  'src/app/plugin/scoped-plugin-registry.ts',
  'src/app/components/reassembly-input-center.component.ts',
  'src/app/components/reassembly-dual-pane.component.ts',
  'src/app/app.component.ts',
];

let failed = false;
for (const rel of files) {
  const full = path.join(cwd, rel);
  if (!fs.existsSync(full)) {
    console.error(`missing ${rel}`);
    failed = true;
    continue;
  }
  const source = fs.readFileSync(full, 'utf8');
  const output = ts.transpileModule(source, {
    fileName: rel,
    reportDiagnostics: true,
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.ESNext,
      experimentalDecorators: true,
    },
  });
  for (const diagnostic of output.diagnostics ?? []) {
    failed = true;
    console.error(`${rel}: ${ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n')}`);
  }
}

const manager = fs.readFileSync(path.join(cwd, 'src/app/components/reassembly-dual-pane.component.ts'), 'utf8');
const engine = fs.readFileSync(path.join(cwd, 'src/app/services/input-engine.service.ts'), 'utf8');
const pane = fs.readFileSync(path.join(cwd, 'src/app/components/reassembly-directory-pane.component.ts'), 'utf8');

const declarativeModule = fs.readFileSync(path.join(cwd, 'src/app/plugin/declarative-plugin-module.ts'), 'utf8');
const loader = fs.readFileSync(path.join(cwd, 'src/app/services/directory-plugin-package-loader.service.ts'), 'utf8');

const checks = [
  ['input center mounted', manager.includes('<app-reassembly-input-center')],
  ['user override engine', engine.includes('applyUserBindingCustomization(')],
  ['conflict inspector', engine.includes('inspectBindingConflicts()')],
  ['drag mouse path', engine.includes("document.addEventListener('mousemove'")],
  ['no compare badge', !pane.includes('compare-badge')],
  ['no old compare status', !manager.includes("item.status !== 'equal'")],
  ['no private linked load', !manager.includes('targetPane.load(peer')],
  ['declarative plugin bindings declared', declarativeModule.includes('bindings?: DeclarativePluginBinding[]')],
  ['loader binding parameter typed', loader.includes('(binding: DeclarativePluginBinding) =>')],
  ['valid trigger predicate',
    engine.includes('value is Exclude<typeof value, undefined>') &&
    !engine.includes("gesture.direction,\n    ].filter((value): value is string")],
];

for (const [label, ok] of checks) {
  if (!ok) {
    console.error(`failed: ${label}`);
    failed = true;
  }
}

if (failed) process.exit(1);
console.log('Phase 74 static integration checks passed.');
