import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';

const cwd=path.resolve(process.cwd());
const files=[
  'src/app/services/discovery-search.service.ts',
  'src/app/services/discovery-history.service.ts',
  'src/app/services/recent-files.service.ts',
  'src/app/services/results-panel.service.ts',
  'src/app/components/reassembly-global-search.component.ts',
  'src/app/components/reassembly-dual-pane.component.ts',
];

let failed=false;
for(const rel of files){
  const full=path.join(cwd,rel);
  if(!fs.existsSync(full)){console.error(`missing ${rel}`);failed=true;continue;}
  const source=fs.readFileSync(full,'utf8');
  const result=ts.transpileModule(source,{
    fileName:rel,reportDiagnostics:true,
    compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,experimentalDecorators:true}
  });
  for(const diagnostic of result.diagnostics??[]){
    failed=true;
    console.error(`${rel}: ${ts.flattenDiagnosticMessageText(diagnostic.messageText,'\n')}`);
  }
}

const search=fs.readFileSync(path.join(cwd,'src/app/components/reassembly-global-search.component.ts'),'utf8');
const discovery=fs.readFileSync(path.join(cwd,'src/app/services/discovery-search.service.ts'),'utf8');
const manager=fs.readFileSync(path.join(cwd,'src/app/components/reassembly-dual-pane.component.ts'),'utf8');

const checks=[
  ['discovery modes',search.includes("type DiscoveryMode = 'search' | 'recent' | 'collections'")],
  ['saved searches',search.includes('saveSearch(): Promise<void>')],
  ['provider fallback',discovery.includes('this.panelSources.list(')],
  ['collection open',manager.includes('openDiscoveryPanelPath(path: string)')],
  ['no stale recentQueries',!search.includes('recentQueries')],
  ['no old compare status',!manager.includes("item.status !== 'equal'")],
  ['no private linked load',!manager.includes('targetPane.load(peer')],
];

for(const [label,ok] of checks){
  if(!ok){console.error(`failed: ${label}`);failed=true;}
}
if(failed)process.exit(1);
console.log('Phase 75 static integration checks passed.');
