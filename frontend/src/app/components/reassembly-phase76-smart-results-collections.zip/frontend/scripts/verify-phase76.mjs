import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';

const cwd=path.resolve(process.cwd());
const files=[
  'src/app/services/results-panel.service.ts',
  'src/app/services/smart-results.service.ts',
  'src/app/plugin/plugin-registry-api.ts',
  'src/app/services/plugin-manager.service.ts',
  'src/app/components/reassembly-directory-pane.component.ts',
];

let failed=false;
for(const rel of files){
  const full=path.join(cwd,rel);
  if(!fs.existsSync(full)){console.error(`missing ${rel}`);failed=true;continue;}
  const source=fs.readFileSync(full,'utf8');
  const result=ts.transpileModule(source,{
    fileName:rel,
    reportDiagnostics:true,
    compilerOptions:{
      target:ts.ScriptTarget.ES2022,
      module:ts.ModuleKind.ESNext,
      experimentalDecorators:true,
    },
  });
  for(const diagnostic of result.diagnostics??[]){
    failed=true;
    console.error(`${rel}: ${ts.flattenDiagnosticMessageText(diagnostic.messageText,'\n')}`);
  }
}

const pane=fs.readFileSync(path.join(cwd,'src/app/components/reassembly-directory-pane.component.ts'),'utf8');
const results=fs.readFileSync(path.join(cwd,'src/app/services/results-panel.service.ts'),'utf8');
const smart=fs.readFileSync(path.join(cwd,'src/app/services/smart-results.service.ts'),'utf8');

const checks=[
  ['outer pane border removed',!pane.includes('.pane.active-pane')],
  ['smart collection bar',pane.includes('results-collection-bar')],
  ['ctrl-r smart refresh path',pane.includes('if (this.activeResultsPanel)') && pane.includes('await this.refreshResultsCollection()')],
  ['refresh lifecycle',results.includes('registerRefresher(') && results.includes('async refresh(path: string)')],
  ['search refresh',smart.includes("origin === 'global-search'")],
  ['recent refresh',smart.includes("origin === 'recent-files'")],
  ['duplicate refresh',smart.includes("origin === 'duplicate-finder'")],
];

for(const [label,ok] of checks){
  if(!ok){console.error(`failed: ${label}`);failed=true;}
}

if(failed)process.exit(1);
console.log('Phase 76 static integration checks passed.');
